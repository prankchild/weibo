import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import register from '../views/register.vue'
import index from '../views/index.vue'
import my from '../views/my.vue'
import myBlog from '../views/myBlog.vue'
import principal from '../views/principal.vue'
import article from '../views/article.vue'
import release from '../component/release.vue'
import login from '../views/login.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/index',
    name: 'index',
    component: index
  },
  {
    path: '/',
    name: 'index',
    component: index
  },
  {
    path: '/register',
    name: 'register',
    component: register
  },
  {
    path: '/Home',
    name: 'Home',
    component: Home
  }, {
    path: '/my',
    name: 'my',
    component: my
  },
  {
    path: '/principal',
    name: 'principal',
    component: principal
  },
  {
    path: '/myBlog',
    name: 'myBlog',
    component: myBlog
  },
  {
    path: '/article',
    name: 'article',
    component: article
  },
  {
    path: '/release',
    name: 'release',
    component: release
  },
  {
    path: '/login',
    name: 'login',
    component: login
  },
  // {
  //   path: '/about',
  //   name: 'About',
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  // }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
