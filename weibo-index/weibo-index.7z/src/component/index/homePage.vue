<template>
  <div class="homePage">
    <!-- 图片 -->
    <div class="talkBox" v-for="(item, index) in weiboData" :key="index">
      <div class="talk-top">
        <div class="avatar"><img src="../../assets/avatar.jpg" alt="" /></div>
        <div class="user">
          <div class="username">菠萝吹雪</div>
          <div class="time">2021.07.09 15:40</div>
        </div>
      </div>
      <div class="talk-main">
        <div class="talktext">今天夜色真美</div>
        <!-- 转发情况 -->
        <div v-if="forword === 0" class="trueForword">
          <div>
            <a href="">@{{ forwordName }}：</a> <span>{{ weibo }}</span>
          </div>
        </div>
        <div class="showImage">
          <div class="imageBox">
            <div
              class="img"
              @click="showImage(item.weibo_id)"
              v-for="(subitem, subindex) in item.image"
              :key="subindex"
            >
              <img :src="subitem.weibo_imgUrl" alt="" />
            </div>
          </div>
        </div>
      </div>
      <div class="talk-foot">
        <div class="foot">
          <div class="icon" v-for="(item, index) in 3" :key="index">
            <div class="iconBox">
              <div class="img">
                <img src="../../assets/forword.png" alt="" />
              </div>
              <div class="num">100</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ImagePreview } from "vant";
export default {
  data() {
    return {
      imgae: [],
      showimg: false,
      forword: 1,
      forwordName: "人民阿宝",
      weibo:
        "在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！",
      weiboData: [],
      user_id: 300001,
    };
  },
  created() {
    this.data();
  },
  methods: {
    async showImage(id) {
      const { data: res } = await this.$http.post("/weibo/weiboImage", null, {
        params: {
          weibo_id: id,
        },
      });
      console.log(res);
      // ImagePreview();
    },
    async data() {
      const Weibo = await this.$http.post("/weibo/weiboData", null, {
        params: {
          user_id: this.user_id,
        },
      });
      console.log(Weibo);
      this.weiboData = Weibo.data.list;
      console.log(this.weiboData);
    },
  },
};
</script>
<style lang="less" scoped>
.talkBox {
  position: relative;
  background: #fff;
  box-shadow: 0 4px 8px 6px rgba(7, 17, 27, 0.06);
  width: 100%;
  margin-bottom: 10px;
  overflow: hidden;
  .talk-top {
    display: flex;
    // background: #789;
    height: 60px;
    width: 100%;
    .avatar {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      margin-left: 10px;
      margin-top: 15px;
      img {
        width: 30px;
        height: 30px;
        border-radius: 50%;
      }
    }
    .user {
      margin-left: 10px;
      margin-top: 12px;
      .username {
        font-size: 14px;
        color: #333;
      }
      .time {
        margin-top: -2px;
        font-size: 12px;
        color: #8e8d92;
      }
    }
  }
  .talk-main {
    .talktext {
      margin: 0 10px 10px 10px;
      overflow: hidden;
      display: -webkit-box;
      text-overflow: ellipsis;
      -webkit-line-clamp: 5; /*要显示的行数*/
      -webkit-box-orient: vertical;
      font-size: 16px;
      line-height: 160%;
    }
    .trueForword {
      background: #f6f6f6;
      width: 100%;
      overflow: hidden;
      div {
        margin: 10px;
        font-size: 16px;
        overflow: hidden;
        display: -webkit-box;
        text-overflow: ellipsis;
        -webkit-line-clamp: 5; /*要显示的行数*/
        -webkit-box-orient: vertical;
        line-height: 160%;
      }
      a {
        color: #0071e3;
      }
    }
    .showImage {
      width: 100%;
      margin: 10px 0;
      .imageBox {
        width: 100%;
        // display: flex;
        margin: 10px 0;
        .img:nth-child(3n + 1) {
          margin-left: 2.5%;
        }
        .img {
          width: 30%;
          float: left;
          margin-right: 2.5%;
          // flex: 0 0 30%;
          img {
            width: 100%;
          }
        }
      }
    }
  }
  .talk-foot {
    border-top: 1px dashed #e0e0e0;
    width: 100%;
    bottom: 0;
    height: 40px;
    overflow: hidden;
    .foot {
      display: flex;
      width: 100%;
      height: 40px;
      .icon {
        text-align: center;
        flex: 1;
        .iconBox {
          margin-left: 50%;
          position: relative;
          left: -25%;
          overflow: hidden;
          .img {
            margin-top: 6px;
            width: 28px;
            height: 28px;
            img {
              width: 28px;
              height: 28px;
            }
          }
          .num {
            margin-top: 8px;
          }
          div {
            float: left;
          }
        }
      }
    }
  }
}
@media screen and(max-width: 320px) {
  .iconBox {
    margin-left: 50%;
    position: relative;
    left: -25%;
    .img {
      margin-top: 10px !important;
      width: 20px !important;
      height: 20px !important;
      img {
        width: 20px !important;
        height: 20px !important;
      }
    }
  }
}
</style>

