<template>
  <div class="article">
    <div class="header">
      <div class="exit" @click="toexit()">
        <i class="iconfont icon-houtui"></i>
      </div>
      <div class="text" @click="toindex()">BoLuo-Weibo</div>
    </div>
    <div class="talkBox">
      <div class="talk-top">
        <div class="avatar"><img src="../assets/avatar.jpg" alt="" /></div>
        <div class="user">
          <div class="username">下雨的季节</div>
          <div class="time">2021.07.07 13:28</div>
        </div>
      </div>
      <div class="talk-main">
        <div class="talktext">{{ weibo }}</div>
        <!-- 转发情况 -->
        <div v-if="forword === 1" class="trueForword">
          <div>
            <a href="">@{{ forwordName }}：</a> <span>{{ weibo }}</span>
          </div>
        </div>
      </div>
      <div class="talk-foot">
        <div class="foot">
          <div class="icon" v-bind:class="iconActive === 0 ? 'iconActive' : ''">
            <div class="iconBox">
              <div class="img">
                <img src="../assets/forword.png" alt="" />
              </div>
              <div class="num">12</div>
            </div>
          </div>
          <div class="icon" v-bind:class="iconActive === 1 ? 'iconActive' : ''">
            <div class="iconBox">
              <div class="img">
                <img src="../assets/comment.png" alt="" />
              </div>
              <div class="num">123</div>
            </div>
          </div>
          <div class="icon" v-bind:class="iconActive === 2 ? 'iconActive' : ''">
            <div class="iconBox">
              <div class="img">
                <img src="../assets/love.png" alt="" />
              </div>
              <div class="num">33</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import exit from "../component/exit.vue";
export default {
  components: { exit },
  data() {
    return {
      iconActive: 0,
      forword: 1,
      forwordName: "人民阿宝",
      weibo:
        "在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！在山的那边海的那边有一群草拟吗！",
    };
  },
  methods: {
    toexit() {
      this.$router.go(-1);
    },
    toindex() {
      this.$router.push("/");
    },
  },
};
</script>

<style lang="less" scoped>
.article {
  z-index: 2;
  position: relative;
  background: #fff;
  .talkBox {
    position: relative;
    background: #fff;
    width: 100%;
    margin-bottom: 10px;
    overflow: hidden;
    .talk-top {
      display: flex;
      // background: #789;
      height: 60px;
      width: 100%;
      .avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-left: 10px;
        margin-top: 15px;
        img {
          width: 30px;
          height: 30px;
          border-radius: 50%;
        }
      }
      .user {
        margin-left: 10px;
        margin-top: 12px;
        .username {
          font-size: 14px;
          color: #333;
        }
        .time {
          margin-top: -2px;
          font-size: 12px;
          color: #8e8d92;
        }
      }
    }
    .talk-main {
      .talktext {
        margin: 0 10px 10px 10px;
        overflow: hidden;
        display: -webkit-box;
        text-overflow: ellipsis;
        -webkit-line-clamp: 5; /*要显示的行数*/
        -webkit-box-orient: vertical;
        font-size: 16px;
        line-height: 160%;
      }
      .trueForword {
        background: #f6f6f6;
        width: 100%;
        overflow: hidden;
        div {
          margin: 10px;
          font-size: 16px;
          overflow: hidden;
          display: -webkit-box;
          text-overflow: ellipsis;
          -webkit-line-clamp: 5; /*要显示的行数*/
          -webkit-box-orient: vertical;
          line-height: 160%;
        }
        a {
          color: #0071e3;
        }
      }
    }
    .talk-foot {
      //   border-top: 1px dashed #e0e0e0;
      border-bottom: 1px dashed #e0e0e0;
      width: 100%;
      bottom: 0;
      height: 40px;
      .foot {
        display: flex;
        width: 100%;
        height: 40px;
        .icon {
          text-align: center;
          flex: 1;
          .iconBox {
            margin-left: 50%;
            position: relative;
            left: -25%;
            overflow: hidden;
            .img {
              margin-top: 6px;
              width: 28px;
              height: 28px;
              img {
                width: 28px;
                height: 28px;
              }
            }
            .num {
              margin-top: 8px;
            }
            div {
              float: left;
            }
          }
        }
      }
    }
  }
}
.iconActive {
  //   color: #0071e3 !important;
  border-bottom: 2px solid #0071e3;
}
</style>