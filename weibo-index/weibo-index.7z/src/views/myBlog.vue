<template>
  <div class="myblog">
    <exit></exit>
    <div class="header">
      <div class="avatar"><img src="../assets/avatar.jpg" alt="" /></div>
      <div class="text">
        <div class="name">Hi菠萝</div>
        <div class="dec">简介: 路漫漫其修远兮</div>
      </div>
      <div class="edit">关注</div>
    </div>
    <div class="data">
      <div>
        <h4>121</h4>
        <h3>微博</h3>
      </div>
      <div>
        <h4>267</h4>
        <h3>关注</h3>
      </div>
      <div>
        <h4>299887</h4>
        <h3>粉丝</h3>
      </div>
    </div>
    <div class="container">
      <homePage></homePage>
    </div>
  </div>
</template>

<script>
import exit from "../component/exit.vue";
import homePage from "../component/index/homePage.vue";
export default {
  components: {
    exit: exit,
    homePage: homePage,
  },
};
</script>

<style lang="less" scoped>
.myblog {
  width: 100%;
  height: 100%;
  background: #fff;
  position: relative;
  z-index: 2;
  .header {
    display: flex;
    margin-top: 10px;
    .avatar {
      margin-left: 10px;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      img {
        width: 60px;
        height: 60px;
        border-radius: 50%;
      }
    }
    .text {
      margin-top: 5px;
      margin-left: 20px;
      .name {
        font-weight: 600;
        font-size: 18px;
        color: #333;
      }
      .dec {
        color: #828282;
        font-size: 14px;
      }
    }
    .edit {
      margin-top: 10px;
      margin-left: auto;
      margin-right: 20px;
      border: 1px solid #333;
      width: 100px;
      height: 30px;
      text-align: center;
      line-height: 30px;
      border-radius: 5px;
      color: #333;
    }
  }
  .data {
    display: flex;
    margin-top: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #e6e6e6;
    div {
      flex: 1;
      text-align: center;
      h4 {
        color: #333;
        font-size: 16px;
      }
      h3 {
        color: #828282;
        font-size: 12px;
      }
    }
  }
}
</style>